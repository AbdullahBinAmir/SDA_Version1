import React, {useState} from 'react'
import { Text, TouchableOpacity, View, StyleSheet,Button, TextInput } from 'react-native'
import { colors } from '../global/Styles';
import Modal from "react-native-modal";

export default function VendorDistributorsCard(
    {
        vdId,
        dname,
        demail,
        mobileno,
        dcity,
        distributionStatus,
        securityAmountPaid,
        distributorAddress,
        screenWidth,
        navigation
    }
) {

    const [isModalVisible, setModalVisible] = useState(false);

    const toggleModal = () => {
        setModalVisible(!isModalVisible);
      };

    return (
      <TouchableOpacity  onPress={()=>{navigation.navigate('DistributorsDetails',{
        id:vdId,name:dname,email:demail,mno:mobileno,dstatus:distributionStatus,sapaid:securityAmountPaid,
        daddress:distributorAddress
  })}}>
        <View style={{...styles.boxStyle, width:screenWidth}}>
            <View style={styles.boxText}>
               <Text style={styles.text1}>Name: {dname}</Text>
               <Text style={styles.text1}>City: {dcity}</Text>
               <Text style={styles.text1}>Status: {distributionStatus}</Text>
              <Text style={styles.text2} onPress={toggleModal} >Change Status</Text>
            </View>
            <View style={{ flex: 1 }}>
                <Modal isVisible={isModalVisible}>
                    <View style={styles.modalView1}>
                    <View style={{marginVertical:10,paddingVertical:10}}>
                        <TextInput style={{borderWidth:2,borderRadius:10,padding:10,marginBottom:10}} placeholder='Enter Security Paid'/>
                        <TextInput style={{borderWidth:2,borderRadius:10,padding:10}} placeholder='Enter Current Status'/>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <View style={{flexDirection:'row',justifyContent:'space-around',margin:10}}>
                            <Button title="Close" onPress={toggleModal} />
                        </View>
                        <View  style={{flexDirection:'row',justifyContent:'space-around',margin:10}}>
                            <Button title='Save' />
                        </View>
                    </View>
                    </View>
                </Modal>
            </View>
        </View>
      </TouchableOpacity>
    )
  }

const styles=StyleSheet.create({
    boxStyle:{
        flex:1,
        backgroundColor:colors.cardbackground,
        alignSelf:'center',
        marginVertical:10
    },
    boxText:{
        borderWidth:3,
        borderColor:colors.buttons,
        marginLeft:10,
        paddingHorizontal:10,
        paddingVertical:15,
        borderRadius:15
    },
    text1:{
        fontSize:16,
        color:'black',
        fontStyle:'italic'
    },
    text2:{
        color:colors.buttons,
        textDecorationLine:'underline',
        padding:10,
        fontSize:16,
        textAlign:'center',
        marginTop:5
    },
    modalView1:{
         flex: 1,
         alignItems:'center',
         justifyContent:'center',
         backgroundColor:colors.grey5,
         borderRadius:30
    }
})