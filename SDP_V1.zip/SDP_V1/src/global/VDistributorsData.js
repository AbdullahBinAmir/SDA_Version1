export const vendorDistributors=[
    {
    vdId:1,
    dname:'Usama Bilal',
    demail:'BILALOSAMA8@GMAIL.COM',
    mobileno:'03168967345',
    dcity:'Rawalpindi',
    distributionStatus:'approved',
    securityAmountPaid:'200000',
    distributorAddress:'105 Range Road'
},
{
    vdId:2,
    dname:'Shoaib Sheikh',
    demail:'SS678@GMAIL.COM',
    mobileno:'03457967294',
    dcity:'Rawalpindi',
    distributionStatus:'applied',
    securityAmountPaid:'not paid',
    distributorAddress:'24 Harley Street'
}
]