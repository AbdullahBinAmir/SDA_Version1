export const vendorProduct=[
    {
        pid:1,
        pname:'OLPERS 1.5 Litre',
        quantityPerCarton:12,
        pricePerCarton:2500,
        purchasePriceDistributor:2300,
        salePriceDistributor:2300,
        no_Of_Carton:1500,
        companyName:'OLPERS',
        thresholdToBuy:500,
        productCategory:'Dairy',
        productDescription:'1.5 litre packk Milk',
        productImage:'https://pictures.grocerapps.com/original/grocerapp-olper-milk-15-litre-carton-5e6cec4d516f1.png'
    },
    {
        pid:2,
        pname:'OLPERS 1 Litre',
        quantityPerCarton:12,
        pricePerCarton:2500,
        purchasePriceDistributor:2300,
        salePriceDistributor:2300,
        no_Of_Carton:1500,
        companyName:'OLPERS',
        thresholdToBuy:500,
        productCategory:'Dairy',
        productDescription:'1 litre packk Milk',
        productImage:'http://dkmart.pk/wp-content/uploads/2020/08/OlpersMilk1000ml12PcsCartonforDKMart.png'
    }
]